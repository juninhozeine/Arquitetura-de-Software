/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author Aluno
 */
public class ControlaLimite {
    public int daLimite(int idade, String pais){
        int limite = 0;
        
        if(idade <= 18){
            limite = 100;
        }
        if(idade > 18 && idade <= 35){
            limite = 300;
        }
        
        if(idade > 35){
            limite = 500;
        }
        
        if(pais == "Brasil"){
            limite += 100;
        }
        
        return limite;
    }
}
