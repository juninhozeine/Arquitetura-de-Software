/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author Aluno
 */
public class ControlaCliente {
    public boolean controlaNome(String nome){
        if(nome.length() >= 5){ 
            return true;
        }else{
            return false;
        }
    }
}
